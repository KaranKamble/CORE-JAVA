package com.main;

import java.util.Scanner;

public class Program {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		System.out.println("Enter Size of Array : ");
		int size = sc.nextInt();
		int arr[] = new int [size];
		
				
	}
	
	public static void main2(String[] args) {
		int [] arr = new int [3];
	}
	public static void main1(String[] args) {
		int arr[] = null;
		arr = new int[3];
	}
	
}
