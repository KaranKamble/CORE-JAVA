package com.main;

public class Program {
	public static void main(String[] args) {
		if( System.out.printf("Hello World") == null ) {	
		}		
	}
}